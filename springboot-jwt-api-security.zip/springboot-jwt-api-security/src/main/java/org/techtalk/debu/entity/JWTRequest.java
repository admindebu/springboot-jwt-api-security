package org.techtalk.debu.entity;

import java.io.Serializable;

public class JWTRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userName;
	private String passWord;

	// need default constructor
	public JWTRequest() {

	}

	public JWTRequest(String userName, String passWord) {
		this.setUserName(userName);
		this.setPassWord(passWord);
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

}
