package org.techtalk.debu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppInitializar {

	public static void main(String[] args) {
		SpringApplication.run(AppInitializar.class, args);
	}
}
